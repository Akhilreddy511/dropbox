import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit {

  @Output() childToParent = new EventEmitter();

  constructor() { }

  countries = [{
    id: 1, name: 'France',
  },
  {
    id: 2, name: 'Germany',
  },
  {
    id: 3, name: 'Italy',
  },
  ];

  ngOnInit(): void {
  }
  onChange(event: any) {
    let selectedCountry: any
    console.log(event)
    console.log(event.target.value)
    selectedCountry = this.countries.filter((x) => x.id == event.target.value);

    console.log(selectedCountry);
    this.childToParent.emit(selectedCountry[0].name);
  }
}
